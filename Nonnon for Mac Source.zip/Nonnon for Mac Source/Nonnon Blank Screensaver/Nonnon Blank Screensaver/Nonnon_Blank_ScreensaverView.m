//
//  Nonnon_Blank_ScreensaverView.m
//  Nonnon Blank Screensaver
//
//  Created by のんのん on 2023/06/25.
//

#import "Nonnon_Blank_ScreensaverView.h"

@implementation Nonnon_Blank_ScreensaverView

- (instancetype)initWithFrame:(NSRect)frame isPreview:(BOOL)isPreview
{
    self = [super initWithFrame:frame isPreview:isPreview];
    if (self) {
        //[self setAnimationTimeInterval:1/30.0];
    }
    return self;
}

- (void)startAnimation
{
    [super startAnimation];
}

- (void)stopAnimation
{
    [super stopAnimation];
}

- (void)drawRect:(NSRect)rect
{

	//[[NSColor blackColor] set];
	//NSRectFill( rect );

    [super drawRect:rect];
}

- (void)animateOneFrame
{
    return;
}

- (BOOL)hasConfigureSheet
{
    return NO;
}

- (NSWindow*)configureSheet
{
    return nil;
}

@end
